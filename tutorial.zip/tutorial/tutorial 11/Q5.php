<?php
// Create the 'fruits' array
$fruits = array("Apple", "Banana", "Orange", "Grapes", "Mango");

// Print each element of the array using a foreach loop
foreach ($fruits as $fruit) {
    echo $fruit . "<br>";
}
?>