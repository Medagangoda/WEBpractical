<html>
    <body>
    <?php
    for($i=5;$i<=15;$i++){

        echo $i." ";
        
    }
   
    ?>     
    </body>
</html>