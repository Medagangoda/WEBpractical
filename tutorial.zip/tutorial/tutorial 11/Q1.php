<?php
// Create variables x and y and assign values
$x = 6;
$y = 4;

// Perform operations
$sum_result = $x + $y;
$difference_result = $x - $y;
$product_result = $x * $y;
$division_result = $x / $y;

// Display the results
echo "Sum : " . $sum_result . "<br>";
echo "Difference : " . $difference_result . "<br>";
echo "Product : " . $product_result . "<br>";
echo "Division : " . $division_result . "<br>";
?>